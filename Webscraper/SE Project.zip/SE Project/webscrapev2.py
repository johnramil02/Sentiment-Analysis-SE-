from typing import Text
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from pathlib import Path
import pandas as pd


shopee = "https://shopee.ph/D'addario-EJ10-EJ11-EJ12-EJ13-EJ15-EJ16-EJ17-EJ26-Bronze-Phospher-Bronze-Acoustic-Guitar-Strings-Daddario-Acoustic-Strings-i.304906400.3474286932"

rating = []


CO = webdriver.FirefoxOptions()
CO.add_argument('--ignore-certificate-errors')
CO.add_argument('--start-maximized')
driver = webdriver.Firefox(executable_path=r'C:\Program Files (x86)\geckodriver.exe',options=CO)

driver.get(shopee)
driver.implicitly_wait(10)

i = 1

title = driver.find_element_by_xpath('/html/body/div[1]/div/div[2]/div[2]/div[2]/div[2]/div[3]/div/div[1]/span')
print(title.text)

while True:
    solid_button = driver.find_element_by_class_name('shopee-button-solid')
    if int(solid_button.text)== 1:
        driver.execute_script('window.scrollTo(0,document.body.scrollHeight);')
        time.sleep(4)
    
        prod_rating_tags = driver.find_elements_by_class_name('shopee-product-rating__tags')
        for prod_rating_tag in prod_rating_tags:  
            rating.append(prod_rating_tag.text)    
            print(prod_rating_tag.text)
    if int(solid_button.text)!= i:
        break;
        
    right_button = driver.find_element_by_xpath('/html/body/div[1]/div/div[2]/div[2]/div[2]/div[3]/div[2]/div[1]/div[2]/div/div[3]/div[2]/button[8]')
    if right_button:
        while True: 
                i = i+1
                right_button.click();
                solid_button = driver.find_element_by_class_name('shopee-button-solid')
                if int(solid_button.text)== i:
                    solid_button = driver.find_element_by_class_name('shopee-button-solid')
                    driver.execute_script('window.scrollTo(0,4000);')                
                    time.sleep(3)
                    prod_rating_tags = driver.find_elements_by_class_name('shopee-product-rating__tags')
                    for prod_rating_tag in prod_rating_tags: 
                        rating.append(prod_rating_tag.text)  
                        print(prod_rating_tag.text)
                if int(solid_button.text)!= i:
                    break;

            
    break;

driver.close()